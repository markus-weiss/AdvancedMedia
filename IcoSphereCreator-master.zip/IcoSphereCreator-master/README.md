# ICO Sphere Mesh Creator

[Unity Package Download](IcoSphereCreator.unitypackage)

![Thumbnaul](ss001.PNG)

## Discription

Create Ico Sphere Mesh Tool for Unity.  
Sphere Map UV.

## Usage

1. Right Click on Project window
1. Select [Create]->[Ico Sphere]
1. Level : Division Level(1-8)  
Radius : Radius
